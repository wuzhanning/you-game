// The native TV shell forwards remote/gamepad input here; no network or JS bridge.
(function(){
  if(!new URLSearchParams(location.search).has('tv'))return;
  // Older TV WebViews do not support CSS min/max or dynamic viewport units.
  function fitTV(){document.body.style.setProperty('--board-height',Math.max(160,Math.min(innerHeight-200,(innerWidth-260)*580/480))+'px');}
  fitTV();window.addEventListener('resize',fitTV);
  window.nativeTV=true;window.tvAxis=0;document.body.classList.add('tv');
  $('gamepad-status').textContent='遥控器：左右移动 · 确认投放 · 上下打开菜单使用道具 · 返回暂停';
  $('hint').textContent='遥控器：左右选位置，确认键投放';
  $('help-intro').textContent='电视遥控器：左右方向键选择位置，确认键投放。两颗相同的星球碰在一起，就会合成更大的星球！';
  $('help-controls').textContent='遥控器：上下方向键打开操作菜单，可选择炸弹、摇一摇、模式和重新开始。菜单内方向键选择，确认执行，返回关闭。游戏中返回键暂停，暂停后确认继续，再按返回退出。';
  $('help-gamepad').textContent='TV 版也支持蓝牙手柄：左摇杆或方向键移动，A 投放，B 炸弹，X 摇一摇，Start 暂停，Select 打开操作菜单。菜单内方向键选择，A 确认，B 返回。';
  let stick=null;
  window.tvStick=function(x,y){
    const direction=direction2048(x,y);
    if(classicActive&&direction&&direction!==stick)classicUI.move(direction);
    stick=direction;
  };
  window.tvInput=function(action){
    unlockAudio();
    const dialog=document.querySelector('dialog[open]');
    if(dialog){
      if(classicActive&&action==='back'&&dialog.id==='classic-menu'){dialog.close();return false;}
      if(action==='back'||action==='menu'||action==='bomb'){dialog.close();return true;}
      const buttons=[...dialog.querySelectorAll('button')].filter(b=>!b.disabled);
      if(['left','right','up','down'].includes(action)){
        const index=buttons.indexOf(document.activeElement),step=['left','up'].includes(action)?-1:1;
        const next=buttons[(index+step+buttons.length)%buttons.length];if(next)next.focus();
      }else if(action==='ok'){
        const button=buttons.includes(document.activeElement)?document.activeElement:buttons[0];if(button)button.click();
      }
      return true;
    }
    if(classicActive){
      if(['left','right','up','down'].includes(action))classicUI.move(action);
      else if(action==='ok')classicUI.confirm();
      else if(['back','menu','pause'].includes(action))classicUI.menu();
      return true;
    }
    if(action==='back'){if(paused||ended)return false;togglePause();return true;}
    if(action==='menu'||action==='up'||action==='down'){$('tv-menu').showModal();return true;}
    if(action==='pause'){togglePause();return true;}
    if(action==='ok'){if(ended)reset();else if(paused)togglePause();else if(bombMode)removePlanet(bombTarget);else requestDrop();return true;}
    if(paused||ended)return true;
    if(action==='left'||action==='right'){
      if(bombMode)selectBombTarget(action==='left'?-1:1);else aim=Math.max(30,Math.min(WIDTH-30,aim+(action==='left'?-18:18)));
    }else if(action==='bomb')toggleBomb();else if(action==='shake')useShake();
    return true;
  };
  $('tv-controls').onclick=()=>classicActive?classicUI.menu():$('tv-menu').showModal();
  const actions={continue:()=>{if(paused&&!ended)togglePause();},bomb:toggleBomb,shake:useShake,mode:()=>$('mode-dialog').showModal(),help:()=>$('help-dialog').showModal(),restart:()=>openRestart()};
  document.querySelectorAll('[data-tv]').forEach(b=>b.onclick=()=>{$('tv-menu').close();actions[b.dataset.tv]();});
})();
